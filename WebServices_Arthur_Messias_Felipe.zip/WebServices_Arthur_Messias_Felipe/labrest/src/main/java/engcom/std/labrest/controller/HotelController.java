package engcom.std.labrest.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;

import engcom.std.labrest.entities.Hotel;
import engcom.std.labrest.exceptions.PessoaNaoEncontradaException;

@RestController
@RequestMapping("/hotel")
public class HotelController {
    private final List<Hotel> agenda = new ArrayList<>();
    private final AtomicLong contador = new AtomicLong();

    @GetMapping
    public List<Hotel> obterTodasPessoas() {
        return this.agenda;
    }

    @GetMapping("/{id}")
    public Hotel obterPessoa(@PathVariable long id) {
        for (Hotel p : this.agenda) {
            if (p.getIdRegistro() == id) {
                return p;
            }
        }
        throw new PessoaNaoEncontradaException(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Hotel adicionarPessoa(@RequestBody Hotel p) {
        Hotel n = new Hotel(contador.incrementAndGet(), p.getLocal(), p.getDataEntrada(), p.getDataSaida(), p.getNumPessoas(), p.getNumQuartos(), p.getDadosCartao());
        this.agenda.add(n);
        return n;
    }

    @PutMapping("/{id}")
    public Hotel atualizarPessoa(@RequestBody Hotel pessoa, @PathVariable long id) {
        for (Hotel p : this.agenda) {
            if (p.getIdRegistro() == id) {
                p.setLocal(pessoa.getLocal());
                p.setDataEntrada(pessoa.getDataEntrada());
                p.setDataSaida(pessoa.getDataSaida());
                p.setNumPessoas(pessoa.getNumPessoas());
                p.setNumQuartos(pessoa.getNumQuartos());
                p.setDadosCartao(pessoa.getDadosCartao());
                return p;
            }
        }
        throw new PessoaNaoEncontradaException(id);
    }

    @DeleteMapping("/{id}")
    public void excluirPessoa(@PathVariable long id) {
        if (!this.agenda.removeIf(p -> p.getIdRegistro() == id)) {
            throw new PessoaNaoEncontradaException(id);
        }
    }

    @ControllerAdvice
    class PessoaNaoEncontrada {
        @ResponseBody
        @ExceptionHandler(PessoaNaoEncontradaException.class)
        @ResponseStatus(HttpStatus.NOT_FOUND)
        String pessoaNaoEncontrada(PessoaNaoEncontradaException p) {
            return p.getMessage();
        }
    }
}