﻿using System;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using System.Text;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text.Json;
using RestSharp;
using Newtonsoft.Json.Linq;

namespace testeConexao
{   
    /*Alunos:
    Arthur Martins de Oliveira - 201940601003
    Messias Barros Silva - 201940601027
    Luis Felipe Soares Coelho - 201940601013
     
    Professor: Warley Júnior
    */
    /*Para a nossa API utilizamos o código de exemplo em aula "labrest" que recebia pessoa e email e registrava estes
     em uma agenda, porém o adaptamos para servir aos propósitos desse trabalho de web services*/
    class Program
    {
        static void Main(string[] args)
        {
            //EnviaRequisicaoGET();
            HotelGET();
            //PostingViagem();
            //PostingHotel();
        }
        /////////Get Para dados preenchidos de Viagem//////////
        public static void EnviaRequisicaoGET()
        {
            var requisicaoWeb = WebRequest.CreateHttp("http://localhost:8080/viagem");  //criamos um Web request com o endereço pra nossa api de viagens
            requisicaoWeb.Method = "GET";                                               //e definimos o método dessa requisição como GET

            using (var resposta = requisicaoWeb.GetResponse())                          //Agora recebemos a resposta do GET que demos no servidor
            {
                var streamDados = resposta.GetResponseStream();                         //como a nossa API tanto recebe como também envia uma série de
                StreamReader reader = new StreamReader(streamDados);                    // dados, é preciso de um GetResponseStream para recebermos o fluxo
                object objResponse = reader.ReadToEnd();                                // de dados, guardamos essa stream num reader do tipo Stream e
                                                                                        // depois o decodificamos para string, para que possamos ler no shell
                Console.WriteLine(objResponse.ToString());
                Console.ReadLine();
                streamDados.Close();                                                    //por últimos fechamos a NOSSA conexão com o servidor
                resposta.Close();
            }
        }

        /////Get Hotel/////
        public static void HotelGET()
        {
            var requisicaoWeb = WebRequest.CreateHttp("http://localhost:8080/hotel");  //Mesma coisa do método Get para viagem, porém agora recebemos
            requisicaoWeb.Method = "GET";                                              // os dados de registro que estão disponíveis na classe Hotel,
                                                                                       //a única mudança real nessa parte do código é o fim da URL
            using (var resposta = requisicaoWeb.GetResponse())                         //que agora nos direciona para a API de hotéis
            {
                var streamDados = resposta.GetResponseStream();
                StreamReader reader = new StreamReader(streamDados);
                object objResponse = reader.ReadToEnd();

                Console.WriteLine(objResponse.ToString());
                Console.ReadLine();
                streamDados.Close();
                resposta.Close();
            }
        }
        /// <summary>
        /// //////////////////////////////////////////////////
        /// </summary>

        //MÉTODO POST para viagem
        public static void PostingViagem()
        {            
            string url = "http://localhost:8080/viagem";  //primeiramente setamos a URL padrão que vai ser usada pra fazer as requisições para a API de viagens

            var httpWebRequest = (HttpWebRequest)WebRequest.Create(url);    //depois criamos um WebRequest usando essa URL e determinamos que o ContentType vai ser
            httpWebRequest.ContentType = "application/json";                //do tipo Json, pra que assim possamos enviar os dados e o servidor reconheça eles
            httpWebRequest.Method = "POST";                                 //Por últimos definimos que o método desse WebRequest(variável httpWebRequest)
                                                                            //vai ser POST, bem como o nome da função

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = "{\"opcaoViagem\":\"ida\","+                                     //Moldamos os dados no formato json, o servidor só vai reconhecer eles se forem
                                "\"origem\":\"Marabá\"," +                                    //digitados assim
                                "\"destino\":\"Acapuco\"," +                                 
                                "\"dataIda\":\"06/07/2022\"," +
                                "\"dataVolta\":\"22/08/2022\","+
                                "\"numPessoas\":\"04\","+
                                "\"dadosCartao\":\"0800.7770.1000-3230, parcelado em 6 vezes\"}";
                streamWriter.Write(json);
            }
            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();               
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))   
            {                                                                               
                var result = streamReader.ReadToEnd();
            }
        }

        ////////Metodo POST para Hotel/////////

        public static void PostingHotel()
        {
            string url = "http://localhost:8080/hotel"; //Mesma coisa que o método POST para a viagem, porém com os dados aceitos na classe Hotel

            var httpWebRequest = (HttpWebRequest)WebRequest.Create(url);    
            httpWebRequest.ContentType = "application/json";                
            httpWebRequest.Method = "POST";                                 

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = "{\"local\":\"Acapuco\"," +                                     //Dados do registro do hotel, no formato json
                                "\"dataEntrada\":\"08/07/2022\"," +
                                "\"dataSaida\":\"22/08/2022\"," +
                                "\"numPessoas\":\"04\"," +
                                "\"numQuartos\":\"02\"," +
                                "\"dadosCartao\":\"0800.7770.1000-3230, a vista\"}";
                streamWriter.Write(json);
            }
            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();               
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
            }
        }
    }
}
