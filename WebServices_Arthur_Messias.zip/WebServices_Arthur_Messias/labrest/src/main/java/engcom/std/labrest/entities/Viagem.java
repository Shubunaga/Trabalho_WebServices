package engcom.std.labrest.entities;

public class Viagem {
    private long id;
    private String opcaoViagem;
    private String origem;
    private String destino;
    private String dataIda;
    private String dataVolta;
    private String numPessoas;
    private String dadosCartao;

    public Viagem() {
    }

    public Viagem(long id, String opcaoViagem, String origem, String destino, String dataIda, String dataVolta, String numPessoas, String dadosCartao) {
        this.id = id;
        this.opcaoViagem = opcaoViagem;
        this.origem = origem;
        this.destino = destino;
        this.dataIda = dataIda;
        this.dataVolta = dataVolta;
        this.numPessoas = numPessoas;
        this.dadosCartao = dadosCartao;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getOpcaoViagem() {
        return opcaoViagem;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOpcaoViagem(String opcaoViagem) {
        this.opcaoViagem = opcaoViagem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getDataIda() {
        return dataIda;
    }

    public void setDataIda(String dataIda) {
        this.dataIda = dataIda;
    }

    public String getDataVolta() {
        return dataVolta;
    }

    public void setDataVolta(String dataVolta) {
        this.dataVolta = dataVolta;
    }

    public String getNumPessoas() {
        return numPessoas;
    }

    public void setNumPessoas(String numPessoas) {
        this.numPessoas = numPessoas;
    }

    public String getDadosCartao() {
        return dadosCartao;
    }

    public void setDadosCartao(String dadosCartao) {
        this.dadosCartao = dadosCartao;
    }
}