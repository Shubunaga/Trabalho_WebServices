package engcom.std.labrest.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;

import engcom.std.labrest.entities.Viagem;
import engcom.std.labrest.exceptions.PessoaNaoEncontradaException;

@RestController
@RequestMapping("/viagem")
public class AgendaController {
    private final List<Viagem> agenda = new ArrayList<>();
    private final AtomicLong contador = new AtomicLong();

    @GetMapping
    public List<Viagem> obterTodasPessoas() {
        return this.agenda;
    }

    @GetMapping("/{id}")
    public Viagem obterPessoa(@PathVariable long id) {
        for (Viagem p : this.agenda) {
            if (p.getId() == id) {
                return p;
            }
        }
        throw new PessoaNaoEncontradaException(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Viagem adicionarPessoa(@RequestBody Viagem p) {
        Viagem n = new Viagem(contador.incrementAndGet(), p.getOpcaoViagem(), p.getOrigem(), p.getDestino(), p.getDataIda(), p.getDataVolta(), p.getNumPessoas(), p.getDadosCartao());
        this.agenda.add(n);
        return n;
    }

    @PutMapping("/{id}")
    public Viagem atualizarPessoa(@RequestBody Viagem pessoa, @PathVariable long id) {
        for (Viagem p : this.agenda) {
            if (p.getId() == id) {
                p.setOpcaoViagem(pessoa.getOpcaoViagem());
                p.setOrigem(pessoa.getOrigem());
                p.setDestino(pessoa.getDestino());
                p.setDataIda(pessoa.getDataIda());
                p.setDataVolta(pessoa.getDataVolta());
                p.setNumPessoas(pessoa.getNumPessoas());
                p.setDadosCartao(pessoa.getDadosCartao());
                return p;
            }
        }
        throw new PessoaNaoEncontradaException(id);
    }

    @DeleteMapping("/{id}")
    public void excluirPessoa(@PathVariable long id) {
        if (!this.agenda.removeIf(p -> p.getId() == id)) {
            throw new PessoaNaoEncontradaException(id);
        }
    }

    @ControllerAdvice
    class PessoaNaoEncontrada {
        @ResponseBody
        @ExceptionHandler(PessoaNaoEncontradaException.class)
        @ResponseStatus(HttpStatus.NOT_FOUND)
        String pessoaNaoEncontrada(PessoaNaoEncontradaException p) {
            return p.getMessage();
        }
    }
}