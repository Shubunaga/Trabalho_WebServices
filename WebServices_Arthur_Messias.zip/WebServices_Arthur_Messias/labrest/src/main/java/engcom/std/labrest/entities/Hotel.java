package engcom.std.labrest.entities;

public class Hotel {
    private long idRegistro;
    private String local;
    private String dataEntrada;
    private String dataSaida;
    private String numPessoas;
    private String numQuartos;
    private String dadosCartao;

    public Hotel() {
    }

    public Hotel(long idRegistro, String local, String dataeEntrada, String dataSaida, String numPessoas, String numQuartos, String dadosCartao) {
        this.idRegistro = idRegistro;
        this.local = local;
        this.dataEntrada = dataeEntrada;
        this.dataSaida = dataSaida;
        this.numPessoas = numPessoas;
        this.numQuartos = numQuartos;
        this.dadosCartao = dadosCartao;
    }

    public long getIdRegistro() {
        return idRegistro;
    }

    public void setIdRegistro(long idRegistro) {
        this.idRegistro = idRegistro;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public String getDataEntrada() {
        return dataEntrada;
    }

    public void setDataEntrada(String dataEntrada) {
        this.dataEntrada = dataEntrada;
    }

    public String getDataSaida() {
        return dataSaida;
    }

    public void setDataSaida(String dataSaida) {
        this.dataSaida = dataSaida;
    }

    public String getNumPessoas() {
        return numPessoas;
    }

    public void setNumPessoas(String numPessoas) {
        this.numPessoas = numPessoas;
    }

    public String getNumQuartos() {
        return numQuartos;
    }

    public void setNumQuartos(String numQuartos) {
        this.numQuartos = numQuartos;
    }
    public String getDadosCartao() {
        return dadosCartao;
    }

    public void setDadosCartao(String dadosCartao) {
        this.dadosCartao = dadosCartao;
    }
}