package engcom.std.labrest.exceptions;

public class PessoaNaoEncontradaException extends RuntimeException {

    public PessoaNaoEncontradaException(long id) {
        super("Não foi possível encontrar registro de viagem com o id: " + id);
    }
}