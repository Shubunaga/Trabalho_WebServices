﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace testeConexao
{
    public class DadosViagem
    {
        [JsonProperty("id")]                            //Dados que serão preenchidos na nossa API de viagens, como serão identificados no formato
        public string Id { get; set; }                  // Json e os métodos disponíveis neles(GET e SET)
        [JsonProperty("OpcaoViagem")]
        public string OpcaoViagem { get; set; }
        [JsonProperty("origem")]
        public string Origem { get; set; }
        [JsonProperty("destino")]
        public string Destino { get; set; }
        [JsonProperty("dataIda")]
        public long dataIda { get; set; }
        [JsonProperty("dataVolta")]
        public long dataVolta { get; set; }
        [JsonProperty("numPessoas")]
        public string numPessoas { get; set; }
        [JsonProperty("dadosCartao")]
        public string dadosCartao { get; set; }

    }
}
