﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
namespace testeConexao
{
    public class DadosHotel
    {
        [JsonProperty("idRegistro")]                        //Dados que serão preenchidos na nossa API do registro em Hotéis,
                                                            //como serão identificados no formato Json e os métodos disponíveis neles(GET e SET
        public string IdRegistro { get; set; }
        [JsonProperty("local")]
        public string Local { get; set; }
        [JsonProperty("dataEntrada")]
        public long DataEntrada { get; set; }
        [JsonProperty("dataSaida")]
        public long DataSaida { get; set; }
        [JsonProperty("numPessoas")]
        public string NumPessoas { get; set; }
        [JsonProperty("numQuartos")]
        public string NumQuartos { get; set; }
        [JsonProperty("dadosCartao")]
        public string dadosCartao { get; set; }

    }
}
